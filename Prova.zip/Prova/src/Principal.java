
public class Principal {

	public static void main(String[] args) {
		Espaco space = new Espaco();
		Jogador jogador = new Jogador();
		Inimigo inimigo = new Inimigo();
		
        space.setTurno(1);
        inimigo.setEnergia(100);
        jogador.setVidas(3);
        jogador.setverificacaoJogador(0);
        jogador.setverificacaoTiro(0);
        
		do{
	        jogador.iniciarJogador();
	        System.out.println();
	        jogador.tiro();
	        System.out.println();
	        
	        space.iniciarEspaco();
	        inimigo.iniciarInimigo();
	        
	        System.out.println("Turno: " +space.getTurno());
	        
	        System.out.println("Energia: " +inimigo.getEnergia()+"%");
	        
	        System.out.println("Vidas: " +jogador.getVidas());
	        
	        space.getSpace()[jogador.getlinhaJogador()-1][jogador.getcolunaJogador()-1] = 1;
	        space.getSpace()[inimigo.getlinhaInimigo()][inimigo.getcolunaInimigo()] = 2;
	        
	        if(jogador.getdirecaoTiro() == 4) {
	            for(int i = 0; i < jogador.getlinhaJogador()-1; i++){
	                for(int j = 0; j < jogador.getcolunaJogador()-1; j++){
	                	space.getSpace()[jogador.getlinhaJogador()-1][j] = 3;
	                    }
	            }
	        }else if(jogador.getdirecaoTiro() == 6) {
	            for(int i = 0; i < 10; i++){
	                for(int j = jogador.getcolunaJogador(); j < 10; j++){
	                	space.getSpace()[jogador.getlinhaJogador()-1][j] = 3;
	                    }
	            }
	        }else if(jogador.getdirecaoTiro() == 8) {
	            for(int i = 0; i < jogador.getlinhaJogador()-1; i++){
	                for(int j = 0; j < jogador.getcolunaJogador()-1; j++){
	                	space.getSpace()[i][jogador.getcolunaJogador()-1] = 3;
	                    }
	            }
	        }else if(jogador.getdirecaoTiro() == 2) {
	            for(int i = jogador.getlinhaJogador(); i < 10; i++){
	                for(int j = 0; j < 10; j++){
	                	space.getSpace()[i][jogador.getcolunaJogador()-1] = 3;
	                    }
	            }
	        }else {
	        	System.out.println("Direção do tiro não identificada, se autoexplodiu.");
	        	System.exit(0);
	        }
	        
	        
	        System.out.println();
	        
	        space.mostrarEspaco();
	        
            for(int i = 0; i < 10; i++){
                for(int j = 0; j < 10; j++){
                	if(space.getSpace()[i][j] == 1) {
                		jogador.setverificacaoJogador(1);
                		break;
                	}
                }
            }
            
            if(jogador.getverificacaoJogador() == 1) {
            	jogador.setverificacaoJogador(0);
            }else {
            	System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\O Jogador colidiu com a nave Inimiga///////////////////////");
            	jogador.setVidas(jogador.getVidas()-1);
            }
	        
            for(int i = 0; i < 10; i++){
                for(int j = 0; j < 10; j++){
                	if(space.getSpace()[i][j] == 2) {
                		jogador.setverificacaoTiro(1);
                		break;
                	}
                }
            }
            if(jogador.getverificacaoTiro() == 1) {
            	System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\Você errou o tiro///////////////////////");
            	jogador.setverificacaoTiro(0);
            }else {
            	System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\Você ACERTOU o tiro///////////////////////");
            	inimigo.setEnergia(inimigo.getEnergia()-10);
            }
            space.setTurno(space.getTurno()+1);
            System.out.println();
	        
		}while((inimigo.getEnergia() != 0) && (jogador.getVidas() != 0));
		
		if(inimigo.getEnergia() == 0) {
			System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\Você DERROTOU o inimigo///////////////////////");
		}else {
			System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\Você foi DERROTADO pelo inimigo///////////////////////");
		}
	}
}
