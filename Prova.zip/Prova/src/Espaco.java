
public class Espaco {

    public Espaco() {
    }

    private int turno;

    private int[][] space;

    public int getTurno() {
        return turno;
    }

    public void setTurno(int turno) {
    	this.turno = turno;
    }

    public int[][] getSpace() {
        return space;
    }

    public void setSpace(int[][] space) {
    	this.space = space;
    }

    public void iniciarEspaco() {
		int[][] vacuo = new int[10][10];
        for(int[] i: vacuo){
            for(int j = 0; j < i.length; j++){
                i[j] = 0;
            }
        }
        setSpace(vacuo);
    }

    public void mostrarEspaco() {
        System.out.print("     (1)  (2)  (3)  (4)  (5)  (6)  (7)  (8)  (9)  (10)\n\n");
        for(int i = 0; i < getSpace().length; i++){
            System.out.print("("+ (i+1) + ")  ");
            for(int j = 0; j < getSpace()[i].length; j++){
                    if(getSpace()[i][j] == 1){
                        System.out.print(" J   ");
                    }
                    else if(getSpace()[i][j] == 2){
                        System.out.print(" I   ");
                    }
                    else if(getSpace()[i][j] == 3){
                        System.out.print(" X   ");
                    }
                    else{
                        System.out.print(" *   ");
                    }
                }
            System.out.println("\n");
        }
    }

}