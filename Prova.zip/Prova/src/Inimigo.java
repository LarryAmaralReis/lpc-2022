
import java.util.Random;

public class Inimigo {
    public Inimigo() {
    }
    
    private int energia;
    
    private int linhaInimigo;

    private int colunaInimigo;

    public void iniciarInimigo() {
    	Random rand = new Random();
    	setlinhaInimigo(rand.nextInt(10));
    	setcolunaInimigo(rand.nextInt(10));
    	//setlinhaInimigo(2);
    	//setcolunaInimigo(2);
    }

    public int getEnergia() {
        return energia;
    }

    public void setEnergia(int energia) {
    	this.energia = energia;
    }
    
    public int getlinhaInimigo() {
        return linhaInimigo;
    }

    public void setlinhaInimigo(int linhaInimigo) {
    	this.linhaInimigo = linhaInimigo;
    }
    
    public int getcolunaInimigo() {
        return colunaInimigo;
    }

    public void setcolunaInimigo(int colunaInimigo) {
    	this.colunaInimigo = colunaInimigo;
    }

}