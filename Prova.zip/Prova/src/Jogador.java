
import java.util.Scanner;

public class Jogador {
	Scanner entrada = new Scanner(System.in);
	
    public Jogador() {
    }

    private int vidas;

    private int linhaJogador;

    private int colunaJogador;
    
    private int direcaoTiro;
    
    private int verificacaoJogador;
    
    private int verificacaoTiro;

    public void iniciarJogador() {
        System.out.print("Linha do Jogador:");
        setlinhaJogador(entrada.nextInt());
        System.out.print("Coluna do Jogador:");
        setcolunaJogador(entrada.nextInt());
        if(getlinhaJogador() > 10 || getcolunaJogador() > 10) {
        	System.out.print("Linha ou Coluna não aceita, refaça a entrada.\n");
        	iniciarJogador();
        }
        
    }

    public void tiro() {
    	System.out.print("      ^      \n      8      \n < 4  X  6 > \n      2      \n      V      \n\n");
        System.out.print("Mostre a direção do Tiro:");
        setdirecaoTiro(entrada.nextInt());
    }

    public int getVidas() {
        return vidas;
    }

    public void setVidas(int vidas) {
    	this.vidas = vidas;
    }
    
    public int getlinhaJogador() {
        return linhaJogador;
    }

    public void setlinhaJogador(int linhaJogador) {
    	this.linhaJogador = linhaJogador;
    }
    
    public int getcolunaJogador() {
        return colunaJogador;
    }

    public void setcolunaJogador(int colunaJogador) {
    	this.colunaJogador = colunaJogador;
    }
    
    public int getdirecaoTiro() {
        return direcaoTiro;
    }

    public void setdirecaoTiro(int direcaoTiro) {
    	this.direcaoTiro = direcaoTiro;
    }
    
    public int getverificacaoJogador() {
        return verificacaoJogador;
    }

    public void setverificacaoJogador(int verificacaoJogador) {
    	this.verificacaoJogador = verificacaoJogador;
    }
    
    public int getverificacaoTiro() {
        return verificacaoTiro;
    }

    public void setverificacaoTiro(int verificacaoTiro) {
    	this.verificacaoTiro = verificacaoTiro;
    }
}